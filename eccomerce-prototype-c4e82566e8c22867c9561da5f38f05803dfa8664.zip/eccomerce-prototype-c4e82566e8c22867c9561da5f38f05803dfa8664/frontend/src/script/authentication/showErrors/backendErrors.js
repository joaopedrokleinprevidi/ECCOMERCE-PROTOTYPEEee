const showErrorsByMiddlewaresInBackEnd = (error) => {
  alert(error);

  //Criar uma lógica para o erro ser impresso na tela para o usuário.
};

export default showErrorsByMiddlewaresInBackEnd;
